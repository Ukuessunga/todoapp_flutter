import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:todoapp/pages/pages_tree.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  var PvController = PageController(initialPage: 0);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          PageView(
            controller: PvController,
            pageSnapping: true,
            onPageChanged: (value) {
              //print("Current page: $value");
            },
            children: [
              Pagina(Colors.amber, "Bem-vindo ao ToDo App",
                  "Anote tudo que precisa fazer de forma simplificada"),
              Pagina(Colors.amber.shade800, "Simplificamos tudo para ti",
                  "Acesse tudo no seu dispositivo, em qualquer parte do mundo"),
              Pagina(Colors.green.shade600, "Comece agora!",
                  "Esperamos que tenha uma boa experiência ^-^",
                  showBtnSeguinte: true),

                  
            ],
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 25),
              child: SmoothPageIndicator(
                  controller: PvController, // PageController
                  count: 3,
                  effect: WormEffect(
                      type: WormType.normal,
                      dotColor: Colors.grey.shade300,
                      activeDotColor: Colors.white),
                  onDotClicked: (index) async {
                    await PvController.animateToPage(index,
                        duration: const Duration(milliseconds: 100),
                        curve: Curves.linear);
                  }),
            ),
          ),
        ],
      ),
      /*bottomNavigationBar: NavigationBar(
        onDestinationSelected: (value) {
          if (value == 0) {
            PvController.previousPage(
                duration: const Duration(milliseconds: 100),
                curve: Curves.linear);
          } else {
            PvController.nextPage(
                duration: const Duration(milliseconds: 100),
                curve: Curves.linear);
          }
        },
        //selectedIndex: 0,
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.arrow_left), label: "Anterior"),
          NavigationDestination(
              icon: Icon(Icons.arrow_right), label: "Seguinte"),
        ],
      ),*/
    );
  }

  Widget BtnSeguinte() {
    return Column(
      children: [
        const SizedBox(height: 25),
        OutlinedButton(
            onPressed: () {
              Navigator.pushReplacement(context,
                  MaterialPageRoute(builder: (context) => const PagesTree()));
            },
            style: OutlinedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: Colors.black54,
                side: const BorderSide(color: Colors.white)),
            child: const Text("Começar")),
      ],
    );
  }

  Widget Pagina(Color corFundo, String titulo, String observacoes,
      {bool showBtnSeguinte = false}) {
    return Container(
      color: corFundo,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              titulo,
              style: const TextStyle(
                fontSize: 25,
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              observacoes,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16, color: Colors.white),
            ),
            if (showBtnSeguinte) BtnSeguinte(),
          ],
        ),
      ),
    );
  }
}
