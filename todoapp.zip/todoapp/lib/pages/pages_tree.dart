import 'package:flutter/material.dart';
import 'package:todoapp/pages/about.page.dart';
import 'package:todoapp/pages/home.page.dart';

class PagesTree extends StatefulWidget {
  const PagesTree({super.key});

  @override
  State<PagesTree> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<PagesTree> {
  int current_page = 0;
  List<Widget> list_pages = [HomePage(), const AboutPage()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: list_pages[current_page],
      bottomNavigationBar: NavigationBar(
        selectedIndex: current_page,
        backgroundColor: Colors.amber,
        //animationDuration: const Duration(milliseconds: 1),
        labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
        onDestinationSelected: (value) {
          setState(() {
            current_page = value;
          });
        },
        destinations: const [
          NavigationDestination(
              selectedIcon: Icon(
                Icons.home_outlined,
              ),
              icon: Icon(
                Icons.home,
              ),
              label: "Tarefas"),
          NavigationDestination(
            selectedIcon: Icon(Icons.help_outline),
            icon: Icon(
              Icons.help,
            ),
            label: "Sobre",
          ),
        ],
      ),
    );
  }
}
