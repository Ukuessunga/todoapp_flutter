import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Sobre o Aplicativo"),
        centerTitle: true,
        backgroundColor: Colors.amber,
        //actions: [Checkbox(value: feito_nova_tarefa, onChanged: (valor) {})],
      ),
      body: const Center(child: Text("Desenvolvido por Aguinaldo Ukuessunga")),
    );
  }
}
