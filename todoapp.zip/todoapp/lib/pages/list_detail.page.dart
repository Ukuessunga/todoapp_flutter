import 'package:flutter/material.dart';
import 'package:todoapp/models/itemLista.model.dart';

class ListDetailPage extends StatelessWidget {
  ListDetailPage({super.key, required this.modelo});
  ItemListaModel modelo;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Sobre a tarefa"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Descrição",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            Text(modelo.Descricao),
            const SizedBox(
              height: 10,
            ),
            const Text("Observações",
                style: TextStyle(fontWeight: FontWeight.bold)),
            Text(modelo.Observacoes),
            const SizedBox(
              height: 10,
            ),
            const Text("Estado", style: TextStyle(fontWeight: FontWeight.bold)),
            Text(modelo.Feito ? "Feito" : "Não Feito"),
          ],
        ),
      ),
    );
  }
}
