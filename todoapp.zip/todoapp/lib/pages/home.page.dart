import 'package:flutter/material.dart';
import 'package:todoapp/components/item.lista.dart';
import 'package:todoapp/components/txt.dart';
import 'package:todoapp/models/itemLista.model.dart';
import 'package:todoapp/pages/list_detail.page.dart';

class HomePage extends StatefulWidget {
  HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();

  List<ItemListaModel> Itens_Lista = [];
  void GetElementosIniciais() {
    for (var i = 0; i < 3; i++) {
      Itens_Lista.add(ItemListaModel(
          Descricao: "Tarefa $i", Feito: true, Observacoes: "Observação $i"));
    }
  }
}

class _HomePageState extends State<HomePage> {
  final TextEditingController txtDescricao_nova_tarefa =
      TextEditingController();
  final TextEditingController txtObservacoes_nova_tarefa =
      TextEditingController();
  bool feito_nova_tarefa = false;

  void MostrarMensagem(String msg,
      {Color cor_fundo = Colors.amber, Color cor_texto = Colors.white}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: cor_fundo,
        duration: const Duration(seconds: 2),
        content: Text(
          msg,
          style: TextStyle(color: cor_texto),
        )));
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    //feito_nova_tarefa = false;
    widget.GetElementosIniciais();
  }

  /*void TrocaValor(int i, bool valor) {
    setState(() {
      widget.Itens_Lista[i].Feito = !valor;
    });

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.amber,
        content: Text("Colocou: ${!valor} no item: $i")));
  }*/
  void AdicionarTarefa() {
    String descricao = txtDescricao_nova_tarefa.text;
    String observacoes = txtObservacoes_nova_tarefa.text;

    //print(descricao);
    if (descricao.isNotEmpty) {
      setState(() {
        widget.Itens_Lista.add(ItemListaModel(
            Descricao: descricao,
            Feito: feito_nova_tarefa,
            Observacoes: observacoes));

        txtDescricao_nova_tarefa.clear();
        txtObservacoes_nova_tarefa.clear();
        feito_nova_tarefa = false;

        MostrarMensagem("Tarefa adicionada com sucesso");
      });
    } else {
      MostrarMensagem("Insira a descrição da tarefa", cor_fundo: Colors.red);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Lista de Tarefas"),
        //automaticallyImplyLeading: false,
        centerTitle: true,
        backgroundColor: Colors.amber,
        //actions: [Checkbox(value: feito_nova_tarefa, onChanged: (valor) {})],
      ),
      body: ListView.builder(
        itemCount: widget.Itens_Lista.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              setState(() {
                widget.Itens_Lista[index].Feito =
                    !widget.Itens_Lista[index].Feito;
              });
              //TrocaValor(index, widget.Itens_Lista[index].Feito);
              /*ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    behavior: SnackBarBehavior.floating,
                    backgroundColor: Colors.amber,
                    content:
                        Text("Abrir ${widget.Itens_Lista[index].Descricao}")));*/
            },
            onDoubleTap: () {
              Navigator.push(context, MaterialPageRoute(
                builder: (context) {
                  return ListDetailPage(modelo: widget.Itens_Lista[index]);
                },
              ));
            },
            child: ItemListaComponent(
              modelo: widget.Itens_Lista[index],
              onSobreClick: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return ListDetailPage(modelo: widget.Itens_Lista[index]);
                  },
                ));
              },
              onMarcarChanged: (v) {
                setState(() {
                  widget.Itens_Lista[index].Feito =
                      !widget.Itens_Lista[index].Feito;
                });
              },
              onApagarClick: () {
                setState(() {
                  widget.Itens_Lista.removeAt(index);
                  MostrarMensagem("Tarefa eliminada com sucesso");
                });
              },
              /*onChanged: (p0) {
                  TrocaValor(index, p0!);
                },*/
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        shape: const CircleBorder(),
        //isExtended: true,
        onPressed: () {},
        backgroundColor: Colors.amber,
        label: Column(
          children: [
            IconButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        backgroundColor: Colors.amber,
                        title: const Text("Criar nova tarefa"),
                        content: SingleChildScrollView(
                          child: Column(
                            children: [
                              TxtComponent(
                                txtController: txtDescricao_nova_tarefa,
                                hintText: "Descrição da tarefa",
                              ),
                              const SizedBox(
                                height: 5,
                              ),
                              TxtComponent(
                                  txtController: txtObservacoes_nova_tarefa,
                                  hintText: "Observações"),
                              /*Row(
                        children: [
                          const Text("Feito:"),
                          Checkbox(
                              value: feito_nova_tarefa,
                              onChanged: (valor) {
                                setState(() {
                                  feito_nova_tarefa = !feito_nova_tarefa;
                                  print(feito_nova_tarefa);
                                });
                              })
                        ],
                      ),*/
                            ],
                          ),
                        ),
                        actions: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              TextButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                style: OutlinedButton.styleFrom(
                                  backgroundColor: Colors.white,
                                ),
                                child: Text("Cancelar",
                                    style:
                                        TextStyle(color: Colors.grey.shade800)),
                              ),
                              TextButton(
                                onPressed: () {
                                  AdicionarTarefa();
                                },
                                style: OutlinedButton.styleFrom(
                                  backgroundColor: Colors.white,
                                ),
                                child: Text("Confirmar",
                                    style:
                                        TextStyle(color: Colors.grey.shade800)),
                              )
                            ],
                          )
                        ],
                      );

                      /*Center(
                  child: Container(
                    //height: 100,
                    //width: 100,
                    color: Colors.red,
                    child: Column(
                      children: [
                        const Text("Criar nova tarefa"),
                        /*const TextField(
                          decoration:
                              InputDecoration(hintText: "Descrição da tarefa"),
                        ),
                        const TextField(
                          decoration: InputDecoration(hintText: "Observações"),
                        ),*/
                        FilledButton(
                            onPressed: () {}, child: const Text("Confirmar"))
                      ],
                    ),
                  ),
                );*/
                    },
                  );
                },
                icon: const Icon(
                  Icons.add,
                  color: Colors.white,
                )),
            IconButton(
                onPressed: () {},
                icon: const Icon(
                  Icons.search,
                  color: Colors.white,
                ))
          ],
        ),
      ),
    );
  }
}
