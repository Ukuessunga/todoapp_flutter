import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:todoapp/models/itemLista.model.dart';

class ItemListaComponent extends StatelessWidget {
  ItemListaComponent(
      {super.key,
      required this.modelo,
      required this.onSobreClick,
      this.onMarcarChanged,
      required this.onApagarClick});
  ItemListaModel modelo;
  Function(bool? v)? onMarcarChanged;
  VoidCallback onSobreClick;
  VoidCallback onApagarClick;
  void doSomething() {}
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 15, right: 15, top: 15, bottom: 5),
      decoration: BoxDecoration(color: Colors.amber.shade200),
      child: Slidable(
        key: const ValueKey(0),

        // The start action pane is the one at the left or the top side.
        startActionPane: ActionPane(
          // A motion is a widget used to control how the pane animates.
          motion: const ScrollMotion(),

          // A pane can dismiss the Slidable.
          dismissible: DismissiblePane(onDismissed: () {
            onApagarClick();
          }),

          // All actions are defined in the children parameter.
          children: [
            // A SlidableAction can have an icon and/or a label.
            SlidableAction(
              onPressed: (context) {
                onApagarClick();
              },
              backgroundColor: const Color(0xFFFE4A49),
              foregroundColor: Colors.white,
              icon: Icons.delete,
              label: 'Apagar',
            ),
          ],
        ),

        // The end action pane is the one at the right or the bottom side.
        endActionPane: ActionPane(
          motion: const ScrollMotion(),
          children: [
            SlidableAction(
              // An action can be bigger than the others.
              flex: 2,
              onPressed: (context) {
                onSobreClick();
              },
              backgroundColor: Colors.green,
              foregroundColor: Colors.white,
              icon: Icons.info,

              label: 'Ver',
            ),
          ],
        ),
        child: ListTile(
            leading: Checkbox(
              activeColor: Colors.green,
              onChanged:
                  onMarcarChanged /*(value) {
                //widget.onChanged(value);
                /*setState(() {
                widget.modelo.Feito = !widget.modelo.Feito;
              });*/
              }*/
              ,
              value: modelo.Feito,
            ),
            title: Text(
              modelo.Descricao,
              style: TextStyle(
                  decoration: modelo.Feito
                      ? TextDecoration.lineThrough
                      : TextDecoration.none),
            ),
            subtitle: Text(modelo.Observacoes),
            trailing: IconButton(
              onPressed: onSobreClick,
              icon: const Icon(Icons.info),
            )),
      ),
    );
  }
}
