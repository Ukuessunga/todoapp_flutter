import 'package:flutter/material.dart';

class TxtComponent extends StatelessWidget {
  TxtComponent({super.key, required this.txtController, this.hintText});
  var txtController = TextEditingController();
  String? hintText;
  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: txtController,
      decoration: InputDecoration(
        hintText: hintText,
        filled: true,
        fillColor: Colors.white,
      ),
    );
  }
}
