class ItemListaModel {
  String Descricao;
  bool Feito;
  String Observacoes;
  ItemListaModel(
      {required this.Descricao, required this.Feito, this.Observacoes = ""});
}
